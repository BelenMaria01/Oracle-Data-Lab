# CMMS Mantenimiento de Activos — V1.8.0 Professional Upgrade

## Cambios incluidos

- Rediseño completo de la navegación lateral por dominios: Mantenimiento, Activos, Inventario, Recursos, Análisis y Administración.
- Shell global oscuro profesional aplicado desde Global Page: cabecera, navegación, tablas, formularios, botones, diálogos, foco y estados.
- Dashboard renovado como **Centro de Control**, con KPI adicional de órdenes críticas y panel de próximos mantenimientos.
- Detalle de OT renovado con cabecera operativa, timeline de estado, acciones rápidas y mejor jerarquía visual.
- Descarga real de adjuntos de OT mediante proceso seguro en la propia página de detalle.
- Escape HTML en el detalle de OT para evitar inyección de contenido introducido por usuarios.
- Formularios de Programación de Mantenimiento y Artículo KB elevados a una presentación modal profesional.
- Nuevo portal para `CLIENTE_ADMIN`: **Tickets de Mi Empresa** (página 29), limitado a los tickets de su empresa.
- Nueva autorización `es-cliente-admin`.
- Job Oracle Scheduler preparado para generar automáticamente las OT preventivas vencidas.
- Índices recomendados para consultas operativas.

## Importación

1. Importar el export APEX de esta carpeta en la aplicación existente.
2. Revisar las páginas 1, 28 y 29 tras importar.
3. Ejecutar `db/UPGRADE_V1.8.0.sql` con el esquema propietario de la aplicación.
4. Comprobar el job `CMMS_GENERAR_OT_MANTENIMIENTO` en `DBA_SCHEDULER_JOBS` / `USER_SCHEDULER_JOBS`.

## Pendiente de una fase posterior

La gestión completa de usuarios del cliente no se ha inventado sobre el esquema actual: el export no contiene una tabla de usuarios de empresa claramente separada de las cuentas APEX. Para implementarla correctamente hay que definir la relación empresa → usuarios y quién puede crear/desactivar cuentas.
