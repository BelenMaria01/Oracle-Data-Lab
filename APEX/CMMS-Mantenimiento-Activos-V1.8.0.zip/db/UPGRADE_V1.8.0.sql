/* CMMS Mantenimiento de Activos - V1.8.0
   Ejecutar una vez en el esquema de la aplicación después de importar el export APEX.
   El job es independiente de APEX y genera automáticamente las OT preventivas vencidas.
*/

BEGIN
    BEGIN
        DBMS_SCHEDULER.DROP_JOB(
            job_name => 'CMMS_GENERAR_OT_MANTENIMIENTO',
            force    => TRUE
        );
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE != -27475 THEN
                RAISE;
            END IF;
    END;

    DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'CMMS_GENERAR_OT_MANTENIMIENTO',
        job_type        => 'PLSQL_BLOCK',
        job_action      => 'BEGIN PKG_MANTENIMIENTOS.generar_ordenes_vencidas; END;',
        start_date      => SYSTIMESTAMP + INTERVAL '5' MINUTE,
        repeat_interval => 'FREQ=DAILY;BYHOUR=06;BYMINUTE=00;BYSECOND=00',
        enabled         => TRUE,
        comments        => 'Genera automáticamente órdenes de trabajo de mantenimiento preventivo vencidas.'
    );
END;
/

/* Índices orientados a las consultas operativas del dashboard y mantenimiento preventivo.
   Si ya existe un índice equivalente, Oracle puede rechazar la creación; esos casos son seguros de ignorar.
*/
BEGIN
    EXECUTE IMMEDIATE 'CREATE INDEX IX_OT_EST_PRI_FECHA ON OP_ORDENES_TRABAJO (ESTADO, PRIORIDAD, FECHA_CREACION)';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE NOT IN (-955, -1408) THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'CREATE INDEX IX_MP_ACTIVO_FECHA ON OP_MANTENIMIENTOS_PROGRAMADOS (ACTIVO, PROXIMA_FECHA)';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE NOT IN (-955, -1408) THEN RAISE; END IF;
END;
/

COMMIT;
